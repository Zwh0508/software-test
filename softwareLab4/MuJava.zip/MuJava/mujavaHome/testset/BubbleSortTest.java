import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.Assert;
public class BubbleSortTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBubbleSort() {
		int arr[] = {1, 6, 2, 2, 5};
		BubbleSort.BubbleSort(arr);
		assertArrayEquals(new int[]{1, 2, 2, 5, 6}, arr);

	}

	@Test
	public void testMain() {
		int arr[] = {3, 7, 4, 2, 1};
		BubbleSort.BubbleSort(arr);
		assertArrayEquals(new int[]{1, 2, 3, 4, 7}, arr);
	}

}
