import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class BackPackTest {

	public BackPack bp;
	@Before
	public void setUp() throws Exception {
			}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testBackPack_Solution1() {
		int m = 10;
		int n = 3;
		int w[] = {3, 4, 5};
        int p[] = {4, 5, 6};
		int c[][] = BackPack.BackPack_Solution(m,n,w,p);
		assertEquals(11,c[n][m]);
	}
	
	@Test
	public void testBackPack_Solution2() {
		int m = 10;
		int n = 5;
		int w[] = {2, 2, 6, 5, 4};
        int p[] = {6, 3, 5, 4, 6};
		int c[][] = BackPack.BackPack_Solution(m,n,w,p);
		assertEquals(15,c[n][m]);
	}

}
